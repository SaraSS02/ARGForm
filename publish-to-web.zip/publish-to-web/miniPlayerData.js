klynt.miniPlayerData = {
    "fullscreenInfoWording": "This program will launch in fullscreen",
    "downloadAppWording": "Download App",
    "thanksForWatchingWording": "Thanks for watching!",
    "description": "",
    "title": "ARG",
    "redirectToMobileApp": "always",
    "yesWording": "Yes",
    "url": "",
    "resumePlaybackWording": "Resume playback?",
    "noWording": "No",
    "thumbnail": "Medias/Photos/PHOTO-2024-05-21-13-17-32.jpg",
    "analyticsKey": "",
    "launchAppWording": "Then Launch Project"
}